package org.example.algorithim2024;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HelloApplication extends Application {

    private ComboBox<String> sourceComboBox;
    private TextArea textArea;
    private ComboBox<String> destinationComboBox;
    private TextField minimumCostField;
    private TextField pathField;
    public static int numOfCities = 0;
    public static String input = "";
    public static String[] city;
    public static int fromCity = 0;
    public static int toCity = 0;
    public static String startingCity;
    public static String destination;

    public static int[][] table;
    public static int d = 0;
    public static String[][] next;

    static class Path {
        private String path;
        private int cost;

        public Path(String path, int cost) {
            this.path = path;
            this.cost = cost;
        }

        public String getPath() {
            return path;
        }

        public int getCost() {
            return cost;
        }
    }

    @Override
    public void start(Stage stage) throws FileNotFoundException {
        stage.setTitle("Minimum Cost Finder");

        Label sourceLabel = new Label("Source:");
        sourceLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: white;");
        sourceComboBox = new ComboBox<>();
        sourceComboBox.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;");
        sourceComboBox.setPrefWidth(250);
        sourceComboBox.setPrefHeight(35);

        Label destinationLabel = new Label("Destination:");
        destinationLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: white;");
        destinationComboBox = new ComboBox<>();
        destinationComboBox.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;");
        destinationComboBox.setPrefWidth(250);
        destinationComboBox.setPrefHeight(35);

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        File initialDirectory = new File("C:\\Users\\hp\\OneDrive\\Desktop");
        fileChooser.setInitialDirectory(initialDirectory);
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        File file = fileChooser.showOpenDialog(stage);
        Scanner sc = new Scanner(file);

        String number = sc.nextLine();
        numOfCities = Integer.parseInt(number);
        int numOfLine = 0;
        city = new String[numOfCities];

        String cityEnd = "";

        input = "";

        while (sc.hasNext()) {
            numOfLine++;
            if (numOfLine == 1) {
                String s = sc.nextLine();
                String[] str = s.split(", ");
                cityEnd = str[1];
                city[0] = str[0];
                city[numOfCities - 1] = str[1];
                continue;
            }

            String s = sc.nextLine();
            input += s + "\n";

            String[] str = s.split(", ");
            city[numOfLine - 2] = str[0];

            sourceComboBox.getItems().addAll(str[0]);
            destinationComboBox.getItems().addAll(str[0]);
        }

        sourceComboBox.getItems().addAll(cityEnd);
        destinationComboBox.getItems().addAll(cityEnd);

        sourceComboBox.setValue(sourceComboBox.getItems().get(0));
        destinationComboBox.setValue(destinationComboBox.getItems().get(numOfCities - 1));

        Label minimumCostLabel = new Label("Minimum Cost:");
        minimumCostLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: white;");
        minimumCostLabel.setPrefWidth(270);
        minimumCostField = new TextField();
        minimumCostField.setPrefWidth(250);
        minimumCostField.setPrefHeight(35);
        minimumCostField.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;");
        minimumCostField.setPromptText("Minimum Cost");

        pathField = new TextField();
        pathField.setEditable(false);
        pathField.setPrefWidth(250);
        pathField.setPrefHeight(35);
        pathField.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;-fx-text-fill: Black;");
        pathField.setPromptText("Path Traversal");

        Label pathLabel = new Label("Best Path:");
        pathLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: white;");

        Button minimumcostbt = new Button("Click Minimum");
        minimumcostbt.setPrefWidth(250);
        minimumcostbt.setPrefHeight(35);
        minimumcostbt.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;-fx-font-size: 15px; -fx-font-weight: bold;");

        minimumcostbt.setOnAction(e -> {
            if (toCity >= fromCity) {
                applyAlgorithm(sourceComboBox, destinationComboBox, input);
                minimumCostField.setText(Integer.toString(table[0][numOfCities - 1]));
            } else
                minimumCostField.setText("Sorry, There is no direct way.");
        });

        Button printPathButton = new Button("Print Path");
        printPathButton.setPrefWidth(250);
        printPathButton.setPrefHeight(35);
        printPathButton.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;-fx-font-size: 15px; -fx-font-weight: bold;");

        printPathButton.setOnAction(e -> {
            String selectedSource = sourceComboBox.getValue();
            String selectedDestination = destinationComboBox.getValue();

            if (selectedSource != null && selectedDestination != null) {
                if (selectedSource.equals(selectedDestination)) {
                    pathField.setText("Error: Source and destination cannot be the same.");
                } else {
                    applyAlgorithm(sourceComboBox, destinationComboBox, input);
                    String path = printPath(next, selectedSource, next[0][numOfCities - 1]) + destination;
                    pathField.setText(path);
                    String path2 = printPath(next, selectedSource, next[1][numOfCities - 1]) + destination;
                    System.out.print("Alternative-Second solution:"+path2);

                }
            } else {
                pathField.setText("Please select source and destination cities first.");
            }
        });



        Button showTableButton = new Button("Show Table");
        showTableButton.setPrefWidth(250);
        showTableButton.setPrefHeight(35);
        showTableButton.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;-fx-font-size: 15px; -fx-font-weight: bold;");

        showTableButton.setOnAction(e -> {
            textArea.setText("");
            if (toCity >= fromCity) {
                StringBuilder outputBuilder = new StringBuilder();
                for (int i = 1; i < toCity; i++) {
                    // no bath
                    if (next[0][i].equals("X")) {
                        // put path that is starting city
                        // from combobox
                        next[0][i] = startingCity;
                    }
                }

                outputBuilder.append("          ");

                // for the first row that have the cities A to end
                for (int i = d; i <= toCity + d; i++) {
                    outputBuilder.append(String.format("%-10s", city[i]));
                }


                outputBuilder.append("\n");

                for (int i = 0; i < numOfCities; i++) { // print the paths
                    // the names of cities in the left of text area
                    outputBuilder.append(String.format("%-10s", city[i + d]));

                    for (int j = 0; j < numOfCities; j++) {
                        // there is no connection
                        if (table[i][j] == Integer.MAX_VALUE || j < i) {

                            // there is no connection i put the "" for these values
                            outputBuilder.append(String.format("%-10s", ""));
                        }
                        else {
                            // if there is connection i put the values in table
                            outputBuilder.append(String.format("%-10s", table[i][j]+""+next[i][j]));
                        }
                        // between the line and another line there is two lines
                        if (j == numOfCities - 1) {
                            outputBuilder.append("\n");
                            outputBuilder.append("\n");
                        }
                    }
                }
                textArea.setStyle("-fx-font-family: 'Courier New', monospaced;");
                textArea.appendText(outputBuilder.toString());
            } else
                textArea.appendText("Sorry, The road is in one way and you can't back.");

        });





        GridPane gridPane = new GridPane();
        gridPane.setStyle("-fx-background-color: #1a2b3d;");
        gridPane.setPadding(new Insets(20));
        gridPane.setVgap(10);
        gridPane.setHgap(10);

        gridPane.add(sourceLabel, 0, 0);
        Label lbstart=new Label("start");
        lbstart.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;-fx-text-fill: Black;");
        lbstart.setPrefWidth(250);
        lbstart.setPrefHeight(35);
        gridPane.add(lbstart, 1, 0);
        gridPane.add(destinationLabel, 0, 1);
        Label lbEnd=new Label("End");
        lbEnd.setStyle("-fx-background-color: #C9E3E6; -fx-background-radius: 20;-fx-text-fill: Black;");
        lbEnd.setPrefWidth(250);
        lbEnd.setPrefHeight(35);
        gridPane.add(lbEnd, 1, 1);
        gridPane.add(minimumCostLabel, 0, 2);
        gridPane.add(minimumCostField, 1, 2);
        gridPane.add(pathLabel, 0, 3);
        gridPane.add(pathField, 1, 3);
        gridPane.add(minimumcostbt, 1, 4);
        gridPane.add(printPathButton, 1, 5);
        gridPane.add(showTableButton, 1, 6);

        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPrefWidth(100);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPrefWidth(250);
        gridPane.getColumnConstraints().addAll(col1, col2);
        gridPane.setAlignment(Pos.CENTER);

        textArea = new TextArea();
        textArea.setPrefSize(200, 400);
        textArea.setEditable(false);
        gridPane.add(textArea, 2, 0, 1, GridPane.REMAINING);

        ColumnConstraints col3 = new ColumnConstraints();
        col3.setHgrow(Priority.ALWAYS);
        gridPane.getColumnConstraints().add(col3);

        Scene scene = new Scene(gridPane, 1000, 600);
        scene.setFill(Color.rgb(175, 238, 238));

        stage.setScene(scene);
        stage.show();
    }

    public static String printPath(String[][] arr, String src, String cities) {
        int size = toCity;
        String path = "";
        int diff = 0;
        while (!cities.equals(src)) {
            for (int j = size; j >= fromCity; j--) {
                if (j == fromCity)
                    break;

                if (city[j + d].equals(cities)) {

                    diff = size - j;
                    path = city[j + d] + " -> " + path; // Start -> B -> E -> I -> J
                    cities = arr[0][toCity - diff]; // I
                }
            }
        }
        return src + " -> " + path;
    }


    public void applyAlgorithm(ComboBox<String> start, ComboBox<String> end, String input) {
        startingCity = start.getValue();
        destination = end.getValue();

        fromCity = start.getSelectionModel().getSelectedIndex();
        toCity = end.getSelectionModel().getSelectedIndex();

        d = fromCity;

        numOfCities = toCity - fromCity + 1;

        table = new int[numOfCities][numOfCities];
        next = new String[numOfCities][numOfCities];

        for (int i = 0; i < numOfCities; i++) {
            for (int j = 0; j < numOfCities; j++) {
                if (i == j)
                    table[i][j] = 0;
                else
                    table[i][j] = Integer.MAX_VALUE;
                next[i][j] = "X";
            }
        }

        String[] line = new String[numOfCities - 1];

        line = input.split("\n");

        for (int i = 0; i < numOfCities-1 ; i++) {
            String[] parts = line[i + fromCity].split(", (?=\\[)");

            int city1 = i;

            for (int j = 1; j < parts.length; j++) {
                String[] cityAndCosts = parts[j].replaceAll("[\\[\\]]", "").split(",");

                String item = cityAndCosts[0].trim();

                int city2 = 0;

                for (int k = fromCity; k <= toCity; k++) {
                    if (start.getItems().get(k).equals(item)) {
                        city2 = k - fromCity;
                        break;
                    }
                }
                int petrolCost = Integer.parseInt(cityAndCosts[1].trim());

                int hotelCost = Integer.parseInt(cityAndCosts[2].trim());

                table[city1][city2] = petrolCost + hotelCost;

            }
        }

        for (int i = 0; i < numOfCities; i++) {
            for (int j = 0; j < numOfCities; j++) {
                if (j < i)
                    table[i][j] = Integer.MAX_VALUE;
                if (i == j)
                    table[i][j] = 0;
            }
        }

        for (int i = 0; i < numOfCities; i++) {
            for (int j = 0; j < numOfCities; j++) {
                for (int k = 0; k < numOfCities; k++) {
                    if (table[j][i] == Integer.MAX_VALUE || table[i][k] == Integer.MAX_VALUE)
                        continue;

                    if (table[j][k] > table[j][i] + table[i][k]) {
                        table[j][k] = table[j][i] + table[i][k];
                        next[j][k] = city[i + d];
                    }
                }
            }
        }

        for (int i = 1; i < numOfCities; i++) {
            if (next[0][i] == "X")
                next[0][i] = startingCity;
            else
                break;
        }

        fromCity = fromCity - d;
        toCity = toCity - d;

        for (int i = 0; i < next.length; i++)
            if (table[0][i] == 0 || table[0][i] == Integer.MAX_VALUE)
                next[0][i] = "X";



    }

    public static void main(String[] args) {
        launch(args);
    }
}
