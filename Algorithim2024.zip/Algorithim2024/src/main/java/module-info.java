module org.example.algorithim2024 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.algorithim2024 to javafx.fxml;
    exports org.example.algorithim2024;
}